﻿Add-PSSnapin Microsoft.Exchange.Management.PowerShell.SnapIn;

# INSERT
Get-Mailbox -RecipientTypeDetails UserMailbox | Select-Object alias, PrimarySmtpAddress | Export-csv C:\Bulklist.csv
Import-Csv "C:\Bulklist.csv" | ForEach{Set-Mailbox -Identity $_.alias -EmailAddresses @{add="smtp:"+$_.Alias+"@lotteasahi.co.kr"}}


# REMOVE
Get-Mailbox -Filter "EmailAddresses -like '*@lotteasahi.co.kr'" -RecipientTypeDetails UserMailbox | ft alias, Emailaddresses, PrimarysmtpAddress
Get-Mailbox -Filter "EmailAddresses -like '*@lotteasahi.co.kr'" -RecipientTypeDetails UserMailbox | Select-Object alias, PrimarysmtpAddress | Export-Csv C:\BulkRemoveList.csv
Import-Csv "C:\BulkRemoveList.csv" | ForEach{Set-Mailbox -Identity $_.alias -EmailAddresses @{Remove="smtp:"+$_.Alias+"@lotteasahi.co.kr"}}